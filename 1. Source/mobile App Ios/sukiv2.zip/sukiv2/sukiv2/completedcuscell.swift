//
//  completedcuscell.swift
//  sukiv2
//
//  Created by electra on 8/4/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class completedcuscell: UITableViewCell {
    
    
    @IBOutlet var date: UILabel!
  
    @IBOutlet var address: UILabel!
    @IBOutlet var outletno: UILabel!
    @IBOutlet var dono: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func setCell(jdate:String, jaddress: String, joutletno: String, jdono: String)    {
        date.text = jdate
        address.text=jaddress
        outletno.text=joutletno
        dono.text=jdono
    }
}