//
//  doCusCellTableViewController.swift
//  sukiv2
//
//  Created by electra on 7/29/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class doCusCellTableViewController:  UITableViewCell {
    
    
    @IBOutlet var Date: UILabel!
    @IBOutlet var address: UILabel!
    @IBOutlet var outletno: UILabel!
    @IBOutlet var dono: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func setCell(Dates:String, donos: String, outletnos: String, addresss: String)    {
        Date.text = Dates
        dono.text=donos
        outletno.text=outletnos
        address.text=addresss
           }
    
}
