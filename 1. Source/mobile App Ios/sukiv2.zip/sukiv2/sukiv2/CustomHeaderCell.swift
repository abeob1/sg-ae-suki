//
//  CustomHeaderCell.swift
//  sukiv2
//
//  Created by electra on 7/27/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class CustomHeaderCell: UITableViewCell {

    @IBOutlet var Hno: UILabel!
    @IBOutlet var Houtletcode: UILabel!
    @IBOutlet var Houtletname: UILabel!
    @IBOutlet var Htotalopen: UILabel!
    @IBOutlet var Haddress: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setCell(nos:String, phone: String, city: String, status: String, email: String)    {
        Hno.text = nos
        Houtletcode.text=phone
        Houtletname.text=city
        Htotalopen.text=status
        Haddress.text=email
    }

}
