//
//  ViewController.swift
//  sukiv2
//
//  Created by electra on 7/22/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var drivernum = ""
    var Burl = ""
    
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
        
    @IBOutlet weak var savebtn: UISwitch!
    
    @IBOutlet var savepass: UISwitch!
    @IBAction func submit(sender: AnyObject) {
        if savepass.on {
            let defaults = NSUserDefaults.standardUserDefaults()
            defaults.setObject(username.text, forKey: "user")
            defaults.setObject(password.text, forKey: "pass")

        } else {
            let defaults = NSUserDefaults.standardUserDefaults()
            defaults.setObject("", forKey: "user")
            defaults.setObject("", forKey: "pass")
    }
        
        
        
    
        self.view.endEditing(true)
               
        let myUrl = NSURL(string: Burl+"DriverLogin");
        
        let request = NSMutableURLRequest(URL:myUrl!);
        
        request.HTTPMethod = "POST";// Compose a query string
        
        //let postString = "userId=Admin&password=0987&dbName=UAT_HSukiGroup";
        
        let postString = "userId="+username.text!+"&password="+password.text!;
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding);
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil
            {
                print("error=\(error)")
                return
            }
            
            // You can print out response object
            //print("Data sss= \(response)")
            
            // Print out response body
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
            let newString = responseString!.stringByReplacingOccurrencesOfString("\"", withString: "")
            //print(newString)
            if newString == "No Records Found!"
            {
                print("No Records Found.")
                let alert = UIAlertController(title:"check your credentials", message:"", preferredStyle:UIAlertControllerStyle.Alert);
                alert.addAction(UIAlertAction(title:"OK",style: UIAlertActionStyle.Default, handler:nil));
                self.presentViewController(alert, animated:true, completion:nil)
            }
            else{
                //print(newString)
                self.drivernum = newString
                let defaults = NSUserDefaults.standardUserDefaults()
                defaults.setObject(newString, forKey: "DriverNo")
                NSOperationQueue.mainQueue().addOperationWithBlock {
                self.performSegueWithIdentifier("loginok", sender: newString)
                //[self performSegueWithIdentifier:"loginok" sender:self];
                }
                
            }
            
            
            
            
        }
        task.resume()
        
   
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = NSUserDefaults.standardUserDefaults()
        //url.setObject("http://116.12.223.8/Publish/SukiWebService/IOSSuki_UAT/Mobile.asmx/", forKey: "APIURL")
        url.setObject("http://54.251.51.69:3879/Mobile.asmx/", forKey: "APIURL")
        
        let urls = NSUserDefaults.standardUserDefaults()
        Burl  = urls.stringForKey("APIURL")!
       
        
        //submit.action
        let defaults = NSUserDefaults.standardUserDefaults()
        if let u = defaults.stringForKey("user")
        {
            username.text=u
            
        }
        if let p = defaults.stringForKey("pass")
        {
            password.text=p
        }
        
        
        
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        let DestViewController : summary = segue.destinationViewController as! summary
        DestViewController.labletext = self.drivernum
    }
    
}

