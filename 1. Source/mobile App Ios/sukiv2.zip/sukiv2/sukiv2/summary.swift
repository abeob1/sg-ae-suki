//
//  summary.swift
//  sukiv2
//
//  Created by electra on 7/25/16.
//  Copyright © 2016 electra. All rights reserved.
//

import Foundation
import UIKit
class summary :UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    
    let headerCellHeight: CGFloat = 55.0
    
    var Burl = ""
    
    @IBOutlet var loading: UIActivityIndicatorView!
    @IBOutlet var mytable: UITableView!
    var labletext = String()
    @IBAction func refreshbtn(sender: AnyObject) {
        TableArray.removeAll();
        OutletCode.removeAll();
        OutletName.removeAll();
        DoQty.removeAll();
        Address.removeAll();
        loaddata();
    }
   
    @IBAction func logout(sender: AnyObject) {
        
        self.performSegueWithIdentifier("logout", sender: nil)
    }
    
    var TableArray = [Int]()
    var OutletCode = [String]()
    var OutletName = [String]()
    var DoQty = [Int]()
    var Address = [String]()
    var selectedID = Int()
    
    func loaddata()
    {
        
        loading.hidden = true;
        //service call Start
        let myUrl = NSURL(string: Burl+"GetSummaryOrder");
        
        let request = NSMutableURLRequest(URL:myUrl!);
        
        request.HTTPMethod = "POST";// Compose a query string
        
        let postString = "driverNo="+labletext;
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding);
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            self.loading.hidden = false;
            if error != nil
            {
                self.loading.hidden = false;
                self.loading.startAnimating()
                print("error=\(error)")
                return
            }
            
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
            
            let newString = responseString!.stringByReplacingOccurrencesOfString("***", withString: "")
            
            var jsonObject: [AnyObject] = try! NSJSONSerialization.JSONObjectWithData(newString.dataUsingEncoding(NSUTF8StringEncoding)!, options: []) as! [AnyObject]
            
            //print(jsonObject[0]["RowNum"])
            //self.tablerowcount = jsonObject.count
            let numberofrow = jsonObject.count-1
            //print("jsoncount:\(numberofrow)")
            for i in 0...numberofrow{
                //print(i)
                let Joutcode = jsonObject[i]["Code"] as! String
                let Joutname = String(jsonObject[i]["Name"] as! String)
                let JDoQty = jsonObject[i]["OpenDOQty"] as! Int
                let JAddress = String(jsonObject[i]["Address"] as! String)
                //print(rownum)
                
                self.TableArray.append(i+1)
                self.OutletCode.append(Joutcode)
                self.OutletName.append(Joutname)
                self.DoQty.append(JDoQty)
                self.Address.append(JAddress)
            }
            self.reload();
            
            
        }
        task.resume()
        
        
        //service call end
    }
    
    func reload()
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            self.mytable.reloadData()
        })
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return TableArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cells:cuscell = tableView.dequeueReusableCellWithIdentifier("cell") as! cuscell
        
        cells.setCell(TableArray[indexPath.row], phone: OutletCode[indexPath.row], city: OutletName[indexPath.row], status: DoQty[indexPath.row], email: Address[indexPath.row])
        //cells.setNeedsUpdateConstraints()
        //cells.updateConstraintsIfNeeded()
        
        return cells
    }
    
     func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let  headerCell = tableView.dequeueReusableCellWithIdentifier("header") as! CustomHeaderCell
        headerCell.backgroundColor = UIColorFromHex(0xAB4605,alpha: 1)
        headerCell.setCell("No", phone: "Outlet Code", city: "Outlet Name", status: "Total Open DO", email: "Address")
        
        return headerCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        selectedID = indexPath.row;
        
        self.performSegueWithIdentifier("GotoDO", sender: nil)
    }
    
    
    
    
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return headerCellHeight
        }
        return headerCellHeight
    }

    
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urls = NSUserDefaults.standardUserDefaults()
        Burl  = urls.stringForKey("APIURL")!

        
        loaddata();
        //mytable.estimatedRowHeight = 100
        mytable.rowHeight = 150
        
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "GotoDO" {
        let DestViewController : deliveryOrder = segue.destinationViewController as! deliveryOrder
        DestViewController.numRecord = DoQty[selectedID]
        DestViewController.driverNo = labletext
        DestViewController.OutletCode = OutletCode[selectedID]
        }
        
    }
}