//
//  completed.swift
//  sukiv2
//
//  Created by electra on 8/3/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class completed: UIViewController, UITableViewDelegate{
    
    
    @IBOutlet var mytable: UITableView!
    @IBOutlet var DeliveryOrder: UILabel!
    @IBOutlet var pono: UILabel!
    @IBOutlet var driver: UILabel!
    @IBOutlet var dates: UITextField!
    @IBOutlet var DeliveryDate: UILabel!
    @IBOutlet var outletcode: UILabel!
    @IBOutlet var status: UILabel!
    
    var DeliveryOrderText = String()
    var drivernumber = String()
    
    var ponoText = String()
    var driverText = String()
    var datesText = String()
    var DeliveryDateText = String()
    var outletcodeText = String()
    var statusText = String()
    var DBText = String()
    var docentrytext = String();
    
    var TableArray = [1,2,3,4]
    var LineNumArray = [String]()
    var DocEntryArray = [String]()
    var ItemCodeArray = [String]()
    var DscriptionArray = [String]()
    var QuantityArray = [String]()
    var U_RecQtyArray = [String]()
    var UnitMsrArray = [String]()
    var WhsCodeArray = [String]()
    var U_AB_POQtyArray  = [String]()
    
    //for back to do
    var numRecord = Int()
    var OutletCode = String()
    var driverNo = String()
    var Burl = ""
    
    let headerCellHeight: CGFloat = 55.0
    
    @IBAction func logout(sender: AnyObject) {
        
        self.performSegueWithIdentifier("logout", sender: nil)
    }
    @IBAction func DoSegment(sender: AnyObject) {
        self.performSegueWithIdentifier("GoBacksummary", sender: nil)
    }
    
    
    
    
    
    
    func loaddata(docentry: String)
    {
        
        //service call Start
        let myUrl = NSURL(string: Burl+"GetCompletedOrder");
        
        let request = NSMutableURLRequest(URL:myUrl!);
        
        request.HTTPMethod = "POST";// Compose a query string
        
        let postString = "driverNo="+docentry;
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding);
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil
            {
                
                print("error=\(error)")
                return
            }
            
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
            
            let newString = responseString!.stringByReplacingOccurrencesOfString("***", withString: "")
            
            var jsonObject: [AnyObject] = try! NSJSONSerialization.JSONObjectWithData(newString.dataUsingEncoding(NSUTF8StringEncoding)!, options: []) as! [AnyObject]
            
            if(jsonObject.count>0)
            {
            let numberofrow = jsonObject.count-1
            //print("jsoncount:\(numberofrow)")
            for i in 0...numberofrow{
                
                let LineNumArrayJ = String(jsonObject[i]["LineNum"] as! Int)
                let DocEntryArrayJ = String(jsonObject[i]["DocEntry"] as! Int)
                let ItemCodeArrayJ = jsonObject[i]["ItemCode"] as! String
                let DscriptionArrayJ = String(jsonObject[i]["Dscription"] as! String)
                let QuantityArrayJ = String(jsonObject[i]["Quantity"] as! Int)
                let U_RecQtyArrayJ = String(jsonObject[i]["U_RecQty"] as! Int)
                let UnitMsrArrayJ = String(jsonObject[i]["UnitMsr"] as! String)
                let WhsCodeArrayJ = String(jsonObject[i]["WhsCode"] as! String)
                let U_AB_POQtyArrayJ = String(jsonObject[i]["U_AB_POQty"] as! Int)
                
                self.TableArray.append(i+1)
                self.LineNumArray.append(LineNumArrayJ)
                self.DocEntryArray.append(DocEntryArrayJ)
                self.ItemCodeArray.append(ItemCodeArrayJ)
                self.DscriptionArray.append(DscriptionArrayJ)
                self.QuantityArray.append(QuantityArrayJ)
                self.U_RecQtyArray.append(U_RecQtyArrayJ)
                self.UnitMsrArray.append(UnitMsrArrayJ)
                self.WhsCodeArray.append(WhsCodeArrayJ)
                self.U_AB_POQtyArray.append(U_AB_POQtyArrayJ)
                
                
            }
                
            }
            else
            {
                NSLog("No data..")
            }
            self.reload()
            
            
        }
        task.resume()
        
        
        //service call end
    }
    
    func reload()
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            self.mytable.reloadData()
        })
    }
    
    
    
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 1
    
    
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cells:completedcuscell = tableView.dequeueReusableCellWithIdentifier("cell") as! completedcuscell
        
        //cells.setCell(String(TableArray[indexPath.row]), jaddress: ItemCodeArray[indexPath.row], joutletno: DscriptionArray[indexPath.row], jdono: QuantityArray[indexPath.row])
        
        return cells
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let  headerCell = tableView.dequeueReusableCellWithIdentifier("header") as! dotablecusheader
        headerCell.backgroundColor = UIColorFromHex(0xAB4605,alpha: 1)
        //headerCell.setCell("No", ItemIds: "Item Id", Descriptions: "Description", doqtys: "DO Qty", poqtys: "PO Qty", Units: "Unit", recqtys: "Rec Qty")
        
        return headerCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        //NSLog(String(TableArray[indexPath.row]));
        //self.performSegueWithIdentifier("gotoDoDetail", sender: nil)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension;
    }
    
    
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return headerCellHeight
        }
        return headerCellHeight
    }
    
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urls = NSUserDefaults.standardUserDefaults()
        Burl  = urls.stringForKey("APIURL")!

        
        let defaults = NSUserDefaults.standardUserDefaults()
        if let d = defaults.stringForKey("DriverNo")
        {
            drivernumber = d
            
        }
        
        loaddata(drivernumber)
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        
        if segue.identifier == "GoBacksummary" {
            let DestDoController : summary = segue.destinationViewController as! summary
            DestDoController.labletext = drivernumber
        }
        
        
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
