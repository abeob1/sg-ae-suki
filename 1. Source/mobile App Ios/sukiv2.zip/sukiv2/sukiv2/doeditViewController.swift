//
//  doeditViewController.swift
//  sukiv2
//
//  Created by electra on 8/2/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class doeditViewController: UIViewController, UITableViewDelegate{
    

    
    @IBOutlet var DateTxtOutlet: UITextField!

    @IBOutlet var mytable: UITableView!
    @IBOutlet var DeliveryOrder: UILabel!
    @IBOutlet var pono: UILabel!
    @IBOutlet var driver: UILabel!
    @IBOutlet var dates: UITextField!
    @IBOutlet var DeliveryDate: UILabel!
    @IBOutlet var outletcode: UILabel!
    @IBOutlet var status: UILabel!
    
    var DeliveryOrderText = String()
    
    var ponoText = String()
    var driverText = String()
    var datesText = String()
    var DeliveryDateText = String()
    var outletcodeText = String()
    var statusText = String()
    var DBText = String()
    var docentrytext = String();
    
    var TableArray = [Int]()
    var LineNumArray = [String]()
    var DocEntryArray = [String]()
    var ItemCodeArray = [String]()
    var DscriptionArray = [String]()
    var QuantityArray = [String]()
    var U_RecQtyArray = [String]()
    var UnitMsrArray = [String]()
    var WhsCodeArray = [String]()
    var U_AB_POQtyArray  = [String]()
    var Burl = ""
    
    
    //for back to do
    var numRecord = Int()
    var OutletCode = String()
    var driverNo = String()
    
    let headerCellHeight: CGFloat = 55.0
    var jsonObject: [AnyObject] = []
   
    
   
    @IBAction func ack(sender: AnyObject) {
        
        if(dates.text=="")
        {
            let alert = UIAlertController(title: "Alert", message: "Select Receipt Date", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)

        }
        else{
            acknow();
        }
    }
    
  
    
    func ackbysave()
    {
        if(dates.text=="")
        {
            let alert = UIAlertController(title: "Alert", message: "Select Receipt Date", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
        else{
            acknow();
        }
    }
    func textFieldDidBeginEditing(textField: UITextField!) {
        let datePickerView:UIDatePicker = UIDatePicker()
        
        datePickerView.datePickerMode = UIDatePickerMode.Date
        
        DateTxtOutlet.inputView = datePickerView
        //self.view.addSubview(datePickerView)
        
        
        datePickerView.addTarget(self, action: Selector("datePickerChanged:"), forControlEvents: UIControlEvents.ValueChanged)

        
    }
    
   

    
    @IBAction func datetouch(sender: UITextField) {
        let datePickerView:UIDatePicker = UIDatePicker()
        
        datePickerView.datePickerMode = UIDatePickerMode.Date
        
        sender.inputView = datePickerView
        //self.view.addSubview(datePickerView)
        
        
        datePickerView.addTarget(self, action: Selector("datePickerChanged:"), forControlEvents: UIControlEvents.ValueChanged)
        
    }
    
    func acknow()
    {
        dispatch_async(dispatch_get_main_queue()) {
            
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject(self.dates.text, forKey: "date")
        defaults.setObject(self.docentrytext, forKey: "DocEntry")
        defaults.setObject(self.DBText, forKey: "DBName")
        defaults.setObject(self.outletcodeText, forKey: "outlet")
        defaults.setObject(self.driverNo, forKey: "driverNo")
        defaults.setObject(self.numRecord, forKey: "numRecord")
        
        //self.dismissViewControllerAnimated(false, completion: nil)
        
        let popOverVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("test") as! DatepickerpopupViewController
        self.addChildViewController(popOverVC)
        popOverVC.view.frame = self.view.frame
        self.view.addSubview(popOverVC.view)
        popOverVC.didMoveToParentViewController(self)
        
        }
    }
    

    
   
    
    func JSONStringify(value: AnyObject,prettyPrinted:Bool = false) -> String{
        
        let options = prettyPrinted ? NSJSONWritingOptions.PrettyPrinted : NSJSONWritingOptions(rawValue: 0)
        
        
        if NSJSONSerialization.isValidJSONObject(value) {
            
            do{
                let data = try NSJSONSerialization.dataWithJSONObject(value, options: options)
                if let string = NSString(data: data, encoding: NSUTF8StringEncoding) {
                    return string as String
                }
            }catch {
                
                print("error")
                //Access error here
            }
            
        }
        return ""
        
    }
    

    
    
    @IBAction func logout(sender: AnyObject) {
        
        self.view.endEditing(true)
        
        if(validateqty()=="true")
        {
        
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .Alert)
        
        alert.view.tintColor = UIColor.blackColor()
        let loadingIndicator: UIActivityIndicatorView = UIActivityIndicatorView(frame: CGRectMake(10, 5, 50, 50)) as UIActivityIndicatorView
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.Gray
        loadingIndicator.startAnimating();
        
        alert.view.addSubview(loadingIndicator)
        presentViewController(alert, animated: true, completion: nil)
        

        
        for i in 1...TableArray.count {
            let tf: UITextField = (mytable.viewWithTag(i) as! UITextField)
            print(tf.text)
            //U_RecQtyArray[i-1] = tf.text!
            
            
            jsonObject.append([
                "LineNum": LineNumArray[i-1],
                "DocEntry": DocEntryArray[i-1],
                "ItemCode": ItemCodeArray[i-i],
                "Dscription": DscriptionArray[i-1],
                "Quantity": QuantityArray[i-1],
                "RecQty": tf.text!,
                "UnitMsr": UnitMsrArray[i-1],
                "WhsCode": WhsCodeArray[i-1],
                "U_AB_POQty": U_AB_POQtyArray[i-1]])
            
        }
        
            //save or update quty
            //service call Start
            let myUrl = NSURL(string: Burl+"PostOrderDetail");
            
            let request = NSMutableURLRequest(URL:myUrl!);
            
            request.HTTPMethod = "POST";// Compose a query string
            
            let postString = "JSONText="+JSONStringify(jsonObject)+"&DBName="+DBText;
            
            request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding);
            
            let tasks = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                data, response, error in
                
                self.dismissViewControllerAnimated(false, completion: nil)
                
                if error != nil
                {
                    
                    print("error=\(error)")
                    return
                }
                
                
                let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
                print("responseString = \(responseString)")
                let newString = responseString!.stringByReplacingOccurrencesOfString("\"", withString: "")
                if(newString == "true")
                {
                    self.ackbysave();
                                    }
                else
                {
                   dispatch_async(dispatch_get_main_queue()) {
                    
                    let alert = UIAlertController(title: "Alert", message: newString, preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "Click", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                    }

                }
                
                
            }
        tasks.resume()
            
        }
        else
        {
            let alert = UIAlertController(title: "Alert", message: "RecQty should not more than DoQty", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)

        }
    }
    @IBAction func DoSegment(sender: AnyObject) {
        self.performSegueWithIdentifier("GoBackDO", sender: nil)
    }
    
    
     func testsegu()
    {
        self.performSegueWithIdentifier("GoBackDO", sender: nil)
    }
    
    func loaddata(docentry: String,Db: String)
    {
        
        NSLog("Working Daawwww")
        
        //service call Start
        let myUrl = NSURL(string: Burl+"GetOrderDetail");
        
        let request = NSMutableURLRequest(URL:myUrl!);
        
        request.HTTPMethod = "POST";// Compose a query string
        
        let postString = "DocEntry="+docentry+"&DBName="+Db;
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding);
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil
            {
                
                print("error=\(error)")
                return
            }
            
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
            
            let newString = responseString!.stringByReplacingOccurrencesOfString("***", withString: "")
            
            var jsonObject: [AnyObject] = try! NSJSONSerialization.JSONObjectWithData(newString.dataUsingEncoding(NSUTF8StringEncoding)!, options: []) as! [AnyObject]
            
            //print(jsonObject[0]["RowNum"])
            //self.tablerowcount = jsonObject.count
            let numberofrow = jsonObject.count-1
            //print("jsoncount:\(numberofrow)")
            for i in 0...numberofrow{
                
                let LineNumArrayJ = String(jsonObject[i]["LineNum"] as! Int)
                let DocEntryArrayJ = String(jsonObject[i]["DocEntry"] as! Int)
                let ItemCodeArrayJ = jsonObject[i]["ItemCode"] as! String
                let DscriptionArrayJ = String(jsonObject[i]["Dscription"] as! String)
                let QuantityArrayJ = String(jsonObject[i]["Quantity"] as! Int)
                let U_RecQtyArrayJ = String(jsonObject[i]["U_RecQty"] as! Int)
                let UnitMsrArrayJ = String(jsonObject[i]["UnitMsr"] as! String)
                let WhsCodeArrayJ = String(jsonObject[i]["WhsCode"] as! String)
                let U_AB_POQtyArrayJ = String(jsonObject[i]["U_AB_POQty"] as! Int)
                
                self.TableArray.append(i+1)
                self.LineNumArray.append(LineNumArrayJ)
                self.DocEntryArray.append(DocEntryArrayJ)
                self.ItemCodeArray.append(ItemCodeArrayJ)
                self.DscriptionArray.append(DscriptionArrayJ)
                self.QuantityArray.append(QuantityArrayJ)
                self.U_RecQtyArray.append(U_RecQtyArrayJ)
                self.UnitMsrArray.append(UnitMsrArrayJ)
                self.WhsCodeArray.append(WhsCodeArrayJ)
                self.U_AB_POQtyArray.append(U_AB_POQtyArrayJ)
                
                
            }
            self.reload()
            
            
        }
        task.resume()
        
        
        //service call end
    }
    
    func reload()
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            self.mytable.reloadData()
        })
    }
    
    
    func validateqty() -> String
    {
        var rval = "true";
        for i in 1...TableArray.count {
            let tf: UITextField = (mytable.viewWithTag(i) as! UITextField)
            print(tf.text)
            //U_RecQtyArray[i-1] = tf.text!
            if(tf.text > self.QuantityArray[i-1])
            {
                rval = "false";
            }
        }
            return rval;
        
    }
    
    
    
    
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return TableArray.count   }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cells:DoEditCusCell = tableView.dequeueReusableCellWithIdentifier("cell") as! DoEditCusCell
        
        cells.setCell(String(TableArray[indexPath.row]), ItemIds: ItemCodeArray[indexPath.row], Descriptions: DscriptionArray[indexPath.row], doqtys: QuantityArray[indexPath.row], poqtys: U_AB_POQtyArray[indexPath.row], Units: UnitMsrArray[indexPath.row], recqtys: U_RecQtyArray[indexPath.row],tag: indexPath.row)
        
        return cells
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let  headerCell = tableView.dequeueReusableCellWithIdentifier("header") as! dotablecusheader
        headerCell.backgroundColor = UIColorFromHex(0xAB4605,alpha: 1)
        headerCell.setCell("No", ItemIds: "Item Id", Descriptions: "Description", doqtys: "DO Qty", poqtys: "PO Qty", Units: "Unit", recqtys: "Rec Qty")
        
        return headerCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        //NSLog(String(TableArray[indexPath.row]));
        //self.performSegueWithIdentifier("gotoDoDetail", sender: nil)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension;
    }
    
    
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return headerCellHeight
        }
        return headerCellHeight
    }
    
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        var datePickerView  : UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePickerMode.Date
    dates.inputView = datePickerView
        datePickerView.addTarget(self, action: Selector("datePickerChanged:"), forControlEvents: UIControlEvents.ValueChanged)

        let urls = NSUserDefaults.standardUserDefaults()
        Burl  = urls.stringForKey("APIURL")!

        DeliveryOrder.text = DeliveryOrderText
        pono.text = ponoText
        driver.text = driverText
        dates.text = datesText
        DeliveryDate.text = DeliveryDateText
        outletcode.text = outletcodeText
        status.text = statusText
        
        loaddata(docentrytext,Db: DBText);
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func datePickerChanged(sender:UIDatePicker){
        
        let dateFormatter = NSDateFormatter()
        
        dateFormatter.dateStyle = NSDateFormatterStyle.ShortStyle
        
        dateFormatter.timeStyle = NSDateFormatterStyle.NoStyle
        dateFormatter.dateFormat = "MM-D-YYYY"
        dates.text = dateFormatter.stringFromDate(sender.date)
        
        
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        
        if segue.identifier == "GoBackDO" {
            let DestDoController : doDetailsViewController = segue.destinationViewController as! doDetailsViewController
            
            
            DestDoController.DeliveryOrderText = DeliveryOrderText
            DestDoController.ponoText = ponoText
            DestDoController.driverText = driverText
            DestDoController.datesText = datesText
            DestDoController.DeliveryDateText = DeliveryDateText
            DestDoController.outletcodeText = outletcodeText
            DestDoController.statusText = statusText
            DestDoController.DBText = DBText
            DestDoController.docentrytext = docentrytext
            
            
            DestDoController.numRecord = numRecord
            DestDoController.OutletCode = OutletCode
            DestDoController.driverNo = driverNo
            DestDoController.docentrytext = docentrytext
            DestDoController.DBText = DBText
        }
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
