//
//  cuscell.swift
//  sukiv2
//
//  Created by electra on 7/26/16.
//  Copyright © 2016 electra. All rights reserved.
//

import Cocoa

class cuscell: UITableViewCell {

}
