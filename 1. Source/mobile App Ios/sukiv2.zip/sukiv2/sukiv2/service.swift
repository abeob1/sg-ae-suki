//
//  service.swift
//  sukiv2
//
//  Created by electra on 8/3/16.
//  Copyright © 2016 electra. All rights reserved.
//

import Foundation

class server {
    var date = "ssss"
    func setackdata(d: String)
    {
        date = d;
    }
    
    func getackdata() -> String
    {
        return date;
    }
    
}
