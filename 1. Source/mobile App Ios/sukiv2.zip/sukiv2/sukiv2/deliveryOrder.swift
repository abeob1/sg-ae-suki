//
//  deliveryOrder.swift
//  sukiv2
//
//  Created by electra on 7/29/16.
//  Copyright © 2016 electra. All rights reserved.
//

import Foundation
import UIKit

class deliveryOrder: UIViewController, UITableViewDelegate {

    @IBOutlet var mytable: UITableView!
    
    @IBAction func logout(sender: AnyObject) {
        self.performSegueWithIdentifier("logout", sender: nil)
    }
    @IBAction func backtosummary(sender: AnyObject) {
        
    self.performSegueWithIdentifier("backtosummary", sender: nil)
    }
    
    let headerCellHeight: CGFloat = 55.0
    let selectedCellHeight: CGFloat = 188.0
    let unselectedCellHeight: CGFloat = 44.0
    
    var numRecord = Int()
    var OutletCode = String()
    var driverNo = String()

    var TableArray = [Int]()
    var DateArray = [String]()
    var DoNoArray = [String]()
    var OutletArray = [String]()
    var AddressArray = [String]()
    var DBnameArray = [String]()
    var NumAtCardArray = [String]()
    var driverNoArray = [String]()
    var outletcodeA = [String]()
    var DescrArray = [String]()
    var U_DBNameArray = [String]()
    var DocEntryArray = [String]()
    
    var do_DeliveryOrderText = String()
    var do_ponoText = String()
    var do_driverText = String()
    var do_datesText = String()
    var do_DeliveryDateText = String()
    var do_outletcodeText = String()
    var do_statusText = String()
    var do_DBText = String()
    var do_docentrytext = String()
    var Burl = ""
    
    
    func loaddata()
    {
        
        //service call Start
        let myUrl = NSURL(string: Burl+"GetWorkingOrder");
        
        let request = NSMutableURLRequest(URL:myUrl!);
        
        request.HTTPMethod = "POST";// Compose a query string
        
        let postString = "numRecord="+String(numRecord)+"&OutletCode="+OutletCode+"&driverNo="+driverNo;
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding);
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil
            {
                
                print("error=\(error)")
                return
            }
            
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
            
            let newString = responseString!.stringByReplacingOccurrencesOfString("***", withString: "")
            
            var jsonObject: [AnyObject] = try! NSJSONSerialization.JSONObjectWithData(newString.dataUsingEncoding(NSUTF8StringEncoding)!, options: []) as! [AnyObject]
            
            //print(jsonObject[0]["RowNum"])
            //self.tablerowcount = jsonObject.count
            let numberofrow = jsonObject.count-1
            //print("jsoncount:\(numberofrow)")
            for i in 0...numberofrow{
                
                let jDateArray = jsonObject[i]["DocDueDate"] as! String
                let jDoNoArray = String(jsonObject[i]["DocNum"] as! String)
                let jOutletArray = jsonObject[i]["CardCode"] as! String
                let JAddress = String(jsonObject[i]["Address2"] as! String)
                let Jdbname = String(jsonObject[i]["U_DBName"] as! String)
                let JNumAtCard = String(jsonObject[i]["NumAtCard"] as! String)
                let JdriverNo = String(jsonObject[i]["U_AB_DriverNo"] as! String)
                let JoutletcodeA = String(jsonObject[i]["OutletCode"] as! String)
                let JDescr = String(jsonObject[i]["Descr"] as! String)
                let JU_DBName = String(jsonObject[i]["U_DBName"] as! String)
                let JDocEntry = String(jsonObject[i]["DocEntry"] as! Int)
                
                //print(rownum)
                
                //let newStartIndex = jDateArray.stringByReplacingOccurrencesOfString("/Date(", withString: "")
               // let newEndIndex = newStartIndex.stringByReplacingOccurrencesOfString(")/", withString: "")
                
               /* let date = NSDate(timeIntervalSince1970: Double(newEndIndex)!)
                //Date formatting
                let dateFormatter = NSDateFormatter()
                dateFormatter.dateFormat = "dd, MMMM yyyy"
                dateFormatter.timeZone = NSTimeZone(name: "UTC")
                let dateString = dateFormatter.stringFromDate(date)*/

                
                self.TableArray.append(i+1)
                self.DateArray.append(jDateArray)
                self.DoNoArray.append(jDoNoArray)
                self.OutletArray.append(jOutletArray)
                self.AddressArray.append(JAddress)
                self.DBnameArray.append(Jdbname)
                self.NumAtCardArray.append(JNumAtCard)
                self.driverNoArray.append(JdriverNo)
                self.outletcodeA.append(JoutletcodeA)
                self.DescrArray.append(JDescr)
                self.U_DBNameArray.append(JU_DBName)
                self.DocEntryArray.append(JDocEntry)
                
            }
           self.reload()
            
            
        }
        task.resume()
        
        
        //service call end
    }
    
    func reload()
    {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            self.mytable.reloadData()
        })
    }
    
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return TableArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cells:doCusCellTableViewController = tableView.dequeueReusableCellWithIdentifier("cell") as! doCusCellTableViewController
        
        cells.setCell(DateArray[indexPath.row], donos: DoNoArray[indexPath.row], outletnos: OutletArray[indexPath.row], addresss: AddressArray[indexPath.row])
        
        return cells
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let  headerCell = tableView.dequeueReusableCellWithIdentifier("header") as! docusheader
        headerCell.backgroundColor = UIColorFromHex(0xAB4605,alpha: 1)
        headerCell.setCell("Address", outlets: "Outlet", Donos: "Do No", dates: "Expected Delivery Date")
        
        return headerCell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        do_DeliveryOrderText = DoNoArray[indexPath.row]
        do_ponoText = NumAtCardArray[indexPath.row]
        do_driverText = driverNoArray[indexPath.row]
        do_DeliveryDateText = DateArray[indexPath.row]
        do_outletcodeText = outletcodeA[indexPath.row]
        do_statusText = DescrArray[indexPath.row]
        do_DBText = U_DBNameArray[indexPath.row]
        do_docentrytext = DocEntryArray[indexPath.row]
        
        self.performSegueWithIdentifier("gotoDoDetail", sender: nil)
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
      return UITableViewAutomaticDimension;
    }
    
    
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return headerCellHeight
        }
        return headerCellHeight
    }
    
    
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urls = NSUserDefaults.standardUserDefaults()
        Burl  = urls.stringForKey("APIURL")!

        
        loaddata();
        mytable.rowHeight = UITableViewAutomaticDimension
        
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        
    if segue.identifier == "gotoDoDetail" {
        let DestDoController : doDetailsViewController = segue.destinationViewController as! doDetailsViewController
        DestDoController.DeliveryOrderText = do_DeliveryOrderText
        DestDoController.ponoText = do_ponoText
        DestDoController.driverText = do_driverText
        DestDoController.datesText = do_datesText
        DestDoController.DeliveryDateText = do_DeliveryDateText
        DestDoController.outletcodeText = do_outletcodeText
        DestDoController.statusText = do_statusText
        DestDoController.DBText = do_DBText
        DestDoController.docentrytext = do_docentrytext
        
        DestDoController.numRecord = numRecord
        DestDoController.OutletCode = OutletCode
        DestDoController.driverNo = driverNo
    }
        if segue.identifier == "backtosummary" {
            
            let DestDoController : summary = segue.destinationViewController as! summary
            DestDoController.labletext = driverNo
        }
        
        
        
        
        
    }

}
