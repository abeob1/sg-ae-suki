//
//  dotablecusheader.swift
//  sukiv2
//
//  Created by electra on 8/2/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class dotablecusheader: UITableViewCell {
    
    
    @IBOutlet var No: UILabel!
    @IBOutlet var ItemId: UILabel!
    @IBOutlet var Description: UILabel!
    @IBOutlet var doqty: UILabel!
    @IBOutlet var poqty: UILabel!
    @IBOutlet var Unit: UILabel!
    @IBOutlet var recqty: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func setCell(Nos:String, ItemIds: String, Descriptions: String, doqtys: String, poqtys: String, Units: String, recqtys: String)    {
        No.text = Nos
        ItemId.text=ItemIds
        Description.text=Descriptions
        doqty.text=doqtys
        poqty.text=poqtys
        Unit.text=Units
        recqty.text=recqtys
    }
}