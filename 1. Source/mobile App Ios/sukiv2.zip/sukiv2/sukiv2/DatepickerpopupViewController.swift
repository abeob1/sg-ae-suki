//
//  DatepickerpopupViewController.swift
//  sukiv2
//
//  Created by electra on 8/2/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit


class DatepickerpopupViewController: UIViewController ,UITextFieldDelegate{
    
    
    @IBOutlet var username: UITextField!
    @IBOutlet var password: UITextField!
    
    var GRPODate = String()
    var DocEntry = String()
    var DBName = String()
    var outlet = String()
    var numbrecord = String()
    var driverno = String()
    var Burl = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let urls = NSUserDefaults.standardUserDefaults()
        Burl  = urls.stringForKey("APIURL")!

        
        
        
        let defaults = NSUserDefaults.standardUserDefaults()
        GRPODate = defaults.stringForKey("date")!
        DocEntry = defaults.stringForKey("DocEntry")!
        DBName = defaults.stringForKey("DBName")!
        outlet = defaults.stringForKey("outlet")!
        numbrecord = defaults.stringForKey("numRecord")!
        driverno = defaults.stringForKey("driverNo")!
        
                
        self.testlable.text = ""
        
        self.view.backgroundColor = UIColor.blackColor().colorWithAlphaComponent(0.8)

        // Do any additional setup after loading the view.
        self.showAnimate()
    }

    @IBOutlet var testlable: UILabel!
    @IBAction func ok(sender: UIButton) {
        
        
        loaddata(GRPODate,DocEntry: DocEntry,DBName: DBName,outlet: outlet);
       
        
        
    }
    @IBAction func close(sender: UIButton) {
        self.removeAnimate()
    }
    
    func loaddata(GRPODate: String,DocEntry: String,DBName: String,outlet: String)
    {
        
        //service call Start
        let myUrl = NSURL(string: Burl+"Acknowledgment");
        
        let request = NSMutableURLRequest(URL:myUrl!);
        
        request.HTTPMethod = "POST";// Compose a query string
        let user = username.text
        let pass = password.text
        
        var postString = "DocEntry="+DocEntry+"&_username="+user!
        postString = postString+"&_password="+pass!+"&_outlet="+outlet
        postString = postString+"&DBName="+DBName+"&GRPODate="+GRPODate
        
         print("postString = \(postString)")
        
        testlable.text = "Loading..."
        
        request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding);
        
        let tasks = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            data, response, error in
            
            if error != nil
            {
                
                print("error=\(error)")
                return
            }
            
            let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
            print("responseString = \(responseString)")
            
            let newString = responseString!.stringByReplacingOccurrencesOfString("\"", withString: "")
            
            print(newString)
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.testlable.text = "*"+newString
                if(newString=="Operation complete successful!")
                {
                    self.performSegueWithIdentifier("GoToDoOncomplete", sender: nil)
                }
                else{
                    //self.performSegueWithIdentifier("GoToCompleted", sender: nil)
                    
                }
                
                
            })
            
        
                
            }
        
            
            
    
        tasks.resume()
        
        
        //service call end
    }
    
    
    
    
    func showAnimate()
    {
        self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
        self.view.alpha = 0.0;
        UIView.animateWithDuration(0.25, animations: {
            self.view.alpha = 1.0
            self.view.transform = CGAffineTransformMakeScale(1.0, 1.0)
        });
    }
    
    func removeAnimate()
    {
        
        UIView.animateWithDuration(0.25, animations: {
            self.view.transform = CGAffineTransformMakeScale(1.3, 1.3)
            self.view.alpha = 0.0;
            }, completion:{(finished : Bool)  in
                if (finished)
                {
                    
                    self.view.removeFromSuperview()
                    
                    
                }
        });
    }
    
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        
        if segue.identifier == "GoToDoOncomplete" {
            
            let DestViewController : deliveryOrder = segue.destinationViewController as! deliveryOrder
            DestViewController.numRecord = Int(numbrecord)!
            DestViewController.driverNo = driverno
            DestViewController.OutletCode = outlet
        }
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
