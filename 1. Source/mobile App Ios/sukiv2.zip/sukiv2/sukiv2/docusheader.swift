//
//  docusheader.swift
//  sukiv2
//
//  Created by electra on 7/29/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class docusheader: UITableViewCell {
    
    
    @IBOutlet var address: UILabel!
    @IBOutlet var outlet: UILabel!
    @IBOutlet var Dono: UILabel!
    @IBOutlet var date: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func setCell(addresss:String, outlets: String, Donos: String, dates: String)    {
        address.text = addresss
        outlet.text=outlets
        Dono.text=Donos
        date.text=dates
        
    }
    
}