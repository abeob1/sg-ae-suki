//
//  mainfun.swift
//  sukiv2
//
//  Created by electra on 7/28/16.
//  Copyright © 2016 electra. All rights reserved.
//

import Foundation
import UIKit

class mainfun: NSObject {
    var name: String = "0"
    
    func getName() -> String{
        name = "Erik Lydecker"
        return name
    }
    
    func convertStringToDictionary(text: String) -> [String:AnyObject]? {
        if let data = text.dataUsingEncoding(NSUTF8StringEncoding) {
            do {
                let json = try NSJSONSerialization.JSONObjectWithData(data, options: .MutableContainers) as? [String:AnyObject]
                print(json)
                return json
            } catch {
                print("Something went wrong")
            }
        }
        return nil
    }
    
}