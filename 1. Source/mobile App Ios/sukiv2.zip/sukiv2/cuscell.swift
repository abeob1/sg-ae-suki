//
//  cuscell.swift
//  sukiv2
//
//  Created by electra on 7/26/16.
//  Copyright © 2016 electra. All rights reserved.
//

import UIKit

class cuscell: UITableViewCell {

   
    @IBOutlet var no: UILabel!
    @IBOutlet var outletcode: UILabel!
    @IBOutlet var outletname: UILabel!
    @IBOutlet var totalopen: UILabel!
    @IBOutlet var address: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setCell(nos:Int, phone: String, city: String, status: Int, email: String)    {
        no.text = String(nos)
        outletcode.text=phone
        outletname.text=city
        totalopen.text=String(status)
        address.text=email
        //address.numberOfLines = 0;
        //address.h  
    }

}
