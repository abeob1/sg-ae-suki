﻿/****************************** Module Header ******************************\
* Module Name: InvalidPage.aspx.cs
* Project:     CSASPNETPreventMultipleWindows
* Copyright (c) Microsoft Corporation
*
* This is invalid page.
* 
* This source is subject to the Microsoft Public License.
* See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL.
* All other rights reserved.
\*****************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Suki
{
    public partial class InvalidPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}