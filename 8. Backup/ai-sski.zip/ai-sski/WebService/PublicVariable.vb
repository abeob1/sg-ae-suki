﻿Class PublicVariable
    'Connection
    'Public Shared oCompany As SAPbobsCOM.Company
End Class
